
Arquivos do convite - Sthephany
------------------------------
Arquivos incluídos:
- index.html
- style.css
- script.js
- admin.html (painel privado com senha 2114)
- video.mp4

Deploy rápido:
- Netlify drop (arrastar pasta): https://app.netlify.com/drop
- GitHub + Vercel: envie os arquivos pro repo e conecte na Vercel

Firebase:
- Ative Firestore e crie coleção 'confirmados'
- Para testes, regras abertas (não deixar assim em produção)
